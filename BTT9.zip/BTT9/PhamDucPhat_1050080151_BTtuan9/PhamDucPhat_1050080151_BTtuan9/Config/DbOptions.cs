namespace Config
{
    /// <summary>
    /// Lớp cấu hình kết nối MySQL
    /// </summary>
    public class DbOptions
    {
        public string Host { get; set; } = "127.0.0.1";
        public uint Port { get; set; } = 3306;
        public string Database { get; set; } = "QuanLyBanSach";
        public string User { get; set; } = "app_user"; // KHÔNG khuyến nghị dùng root
        public string Password { get; set; } = "";

        /// <summary>
        /// Chuyển đổi DbOptions thành connection string cho MySqlConnector
        /// </summary>
        public string ToConnectionString()
            => $"Server={Host};Port={Port};Database={Database};User ID={User};Password={Password};" +
               "SslMode=Preferred;AllowPublicKeyRetrieval=True;Connection Timeout=15;DefaultCommandTimeout=30;";
    }
}


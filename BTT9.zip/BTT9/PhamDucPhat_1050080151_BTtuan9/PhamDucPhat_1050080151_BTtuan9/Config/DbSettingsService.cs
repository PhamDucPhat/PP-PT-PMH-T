using System;
using System.IO;
using System.Text.Json;

namespace Config
{
    /// <summary>
    /// Service để lưu và đọc cấu hình database từ file JSON
    /// File lưu tại: AppData/Roaming/[AppName]/dbsettings.json
    /// </summary>
    public static class DbSettingsService
    {
        private static readonly string SettingsFilePath;
        private static readonly JsonSerializerOptions JsonOptions = new()
        {
            WriteIndented = true,
            Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
        };

        static DbSettingsService()
        {
            var appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var appFolder = Path.Combine(appDataPath, "PhamDucPhat_1050080151_BTtuan9");
            if (!Directory.Exists(appFolder))
            {
                Directory.CreateDirectory(appFolder);
            }
            SettingsFilePath = Path.Combine(appFolder, "dbsettings.json");
        }

        /// <summary>
        /// Lưu cấu hình database vào file JSON
        /// </summary>
        public static void Save(DbOptions options)
        {
            try
            {
                var json = JsonSerializer.Serialize(options, JsonOptions);
                File.WriteAllText(SettingsFilePath, json);
            }
            catch (Exception ex)
            {
                throw new Exception($"Không thể lưu cấu hình: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Đọc cấu hình database từ file JSON
        /// </summary>
        /// <returns>DbOptions nếu file tồn tại, null nếu chưa có</returns>
        public static DbOptions? Load()
        {
            try
            {
                if (!File.Exists(SettingsFilePath))
                {
                    return null;
                }

                var json = File.ReadAllText(SettingsFilePath);
                return JsonSerializer.Deserialize<DbOptions>(json, JsonOptions);
            }
            catch (Exception ex)
            {
                throw new Exception($"Không thể đọc cấu hình: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Kiểm tra file cấu hình đã tồn tại chưa
        /// </summary>
        public static bool SettingsExist()
        {
            return File.Exists(SettingsFilePath);
        }
    }
}


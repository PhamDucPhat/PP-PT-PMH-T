namespace Config
{
    /// <summary>
    /// Lớp cấu hình ứng dụng - chứa chuỗi kết nối MySQL
    /// TODO: Sửa chuỗi kết nối theo máy của bạn
    /// </summary>
    public static class AppConfig
    {
        // TODO: sửa chuỗi kết nối theo máy của bạn
        public const string ConnString =
            "Server=127.0.0.1;Port=3306;Database=QuanLyBanSach;User ID=root;Password=your_password;SslMode=Preferred;Connection Timeout=15;";
    }
}


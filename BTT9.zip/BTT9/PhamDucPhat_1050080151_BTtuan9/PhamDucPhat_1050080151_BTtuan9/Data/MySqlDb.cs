using MySqlConnector;
using Config;

namespace Data
{
    /// <summary>
    /// Helper class để quản lý kết nối MySQL
    /// </summary>
    public static class MySqlDb
    {
        /// <summary>
        /// Tạo và trả về MySqlConnection từ DbOptions
        /// </summary>
        /// <param name="options">Cấu hình database</param>
        /// <returns>MySqlConnection mới</returns>
        public static MySqlConnection Get(DbOptions options)
            => new MySqlConnection(options.ToConnectionString());

        /// <summary>
        /// Tạo và trả về MySqlConnection từ connection string (backward compatibility)
        /// </summary>
        /// <param name="connString">Chuỗi kết nối MySQL</param>
        /// <returns>MySqlConnection mới</returns>
        public static MySqlConnection GetConnection(string connString)
            => new MySqlConnection(connString);
    }
}


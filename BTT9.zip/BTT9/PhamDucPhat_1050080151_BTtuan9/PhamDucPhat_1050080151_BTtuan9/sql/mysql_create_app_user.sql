-- ============================================================
-- Script tạo user riêng cho ứng dụng (không dùng root)
-- Chạy trên MySQL 8, đăng nhập bằng tài khoản có đủ quyền (root)
-- ============================================================

-- Tạo user mới (thay 'your_strong_password' bằng mật khẩu thật)
CREATE USER IF NOT EXISTS 'app_user'@'localhost' IDENTIFIED BY 'your_strong_password';

-- Cấp quyền CRUD cho database QuanLyBanSach
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, INDEX, ALTER
ON QuanLyBanSach.* TO 'app_user'@'localhost';

-- Làm mới quyền
FLUSH PRIVILEGES;

-- ============================================================
-- Nếu vẫn bị lỗi 1045 do plugin xác thực, có thể ép lại plugin:
-- ============================================================

-- Option 1: Dùng mysql_native_password (tương thích tốt với MySqlConnector)
-- ALTER USER 'app_user'@'localhost' IDENTIFIED WITH mysql_native_password BY 'your_strong_password';

-- Option 2: Dùng caching_sha2_password (mặc định MySQL 8)
-- ALTER USER 'app_user'@'localhost' IDENTIFIED WITH caching_sha2_password BY 'your_strong_password';

-- Sau khi ALTER, chạy lại:
-- FLUSH PRIVILEGES;

-- ============================================================
-- Kiểm tra user đã tạo:
-- ============================================================
-- SELECT user, host, plugin FROM mysql.user WHERE user = 'app_user';

-- ============================================================
-- Xóa user (nếu cần):
-- ============================================================
-- DROP USER IF EXISTS 'app_user'@'localhost';


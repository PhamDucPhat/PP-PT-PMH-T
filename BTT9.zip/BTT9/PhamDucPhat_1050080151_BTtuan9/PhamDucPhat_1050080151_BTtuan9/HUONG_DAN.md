# HƯỚNG DẪN SỬ DỤNG - QUẢN LÝ NHÀ XUẤT BẢN

## 📋 TỔNG QUAN

Ứng dụng WinForms .NET 8 quản lý CRUD bảng `NhaXuatBan` trong database MySQL `QuanLyBanSach`.

## 🏗️ CẤU TRÚC DỰ ÁN

```
PhamDucPhat_1050080151_BTtuan9/
├── Config/
│   └── AppConfig.cs          # Cấu hình connection string
├── Data/
│   └── MySqlDb.cs            # Helper class quản lý kết nối MySQL
├── Forms/
│   ├── PublisherForm.cs      # Form chính (code-behind)
│   └── PublisherForm.Designer.cs  # UI layout
├── Program.cs                # Entry point
└── PhamDucPhat_1050080151_BTtuan9.csproj  # Project file
```

## 📦 DEPENDENCIES

- **.NET 8.0** (Target Framework: `net8.0-windows`)
- **MySqlConnector** (Version 2.4.0) - NuGet package

## ⚙️ CẤU HÌNH CONNECTION STRING

### Bước 1: Mở file `Config/AppConfig.cs`

### Bước 2: Sửa chuỗi kết nối

```csharp
public const string ConnString =
    "Server=127.0.0.1;Port=3306;Database=QuanLyBanSach;User ID=root;Password=your_password;SslMode=Preferred;Connection Timeout=15;";
```

### Bước 3: Điều chỉnh theo môi trường của bạn

**Ví dụ với XAMPP (mặc định):**
```csharp
public const string ConnString =
    "Server=127.0.0.1;Port=3306;Database=QuanLyBanSach;User ID=root;Password=;SslMode=Preferred;Connection Timeout=15;";
```

**Ví dụ với MySQL Server riêng:**
```csharp
public const string ConnString =
    "Server=192.168.1.100;Port=3306;Database=QuanLyBanSach;User ID=admin;Password=mypass123;SslMode=Preferred;Connection Timeout=15;";
```

### Tham số chuỗi kết nối:

| Tham số | Mô tả | Ví dụ |
|---------|-------|-------|
| `Server` | Địa chỉ MySQL server | `127.0.0.1`, `localhost`, `192.168.1.100` |
| `Port` | Cổng MySQL | `3306` (mặc định) |
| `Database` | Tên database | `QuanLyBanSach` |
| `User ID` | Tên người dùng MySQL | `root` |
| `Password` | Mật khẩu MySQL | Để trống nếu không có |
| `SslMode` | Chế độ SSL | `Preferred`, `None`, `Required` |
| `Connection Timeout` | Timeout kết nối (giây) | `15` |

## 🗄️ CẤU TRÚC DATABASE

### Database: `QuanLyBanSach`

### Bảng: `NhaXuatBan`

```sql
CREATE DATABASE IF NOT EXISTS QuanLyBanSach;

USE QuanLyBanSach;

CREATE TABLE IF NOT EXISTS NhaXuatBan (
    XB INT AUTO_INCREMENT PRIMARY KEY,
    TenXB VARCHAR(150) NOT NULL UNIQUE,
    DiaChi VARCHAR(255),
    INDEX idx_TenXB (TenXB)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

### Script INSERT dữ liệu mẫu:

```sql
INSERT INTO NhaXuatBan (TenXB, DiaChi) VALUES
('Nhà Xuất Bản Giáo Dục', '123 Đường Láng, Đống Đa, Hà Nội'),
('Nhà Xuất Bản Trẻ', '161B Lý Chính Thắng, Phường 7, Quận 3, TP.HCM'),
('Nhà Xuất Bản Kim Đồng', '55 Quang Trung, Hai Bà Trưng, Hà Nội');
```

## 🎯 CHỨC NĂNG

### 1. **Load (Tải dữ liệu)**
- Nút: `btnLoad`
- Chức năng: Tải toàn bộ dữ liệu từ bảng `NhaXuatBan` vào DataGridView
- Query: `SELECT XB, TenXB, DiaChi FROM NhaXuatBan ORDER BY XB;`

### 2. **Add (Thêm mới)**
- Nút: `btnAdd`
- Chức năng: Thêm nhà xuất bản mới
- Validation:
  - `TenXB`: Bắt buộc, tối đa 150 ký tự
  - `DiaChi`: Tối đa 255 ký tự (không bắt buộc)
- Xử lý: Nhập tên/địa chỉ → Click "Thêm" → Tự động reload và clear form

### 3. **Update (Cập nhật)**
- Nút: `btnUpdate` (hiển thị "Sửa")
- Chức năng: Cập nhật thông tin nhà xuất bản đã chọn
- Cách dùng: 
  1. Click chọn dòng trong DataGridView
  2. Dữ liệu tự động đổ vào textbox
  3. Sửa thông tin
  4. Click "Sửa"

### 4. **Delete (Xóa)**
- Nút: `btnDelete` (hiển thị "Xóa")
- Chức năng: Xóa nhà xuất bản đã chọn
- Cách dùng:
  1. Click chọn dòng trong DataGridView
  2. Click "Xóa"
  3. Xác nhận trong hộp thoại

### 5. **Clear (Xóa form)**
- Nút: `btnClear`
- Chức năng: Xóa trắng tất cả textbox (không xóa dữ liệu trong DB)
- Áp dụng: `txtXB`, `txtTenXB`, `txtDiaChi`

### 6. **CellClick (Chọn dòng)**
- Sự kiện: Click vào bất kỳ cell nào trong DataGridView
- Chức năng: Tự động đổ dữ liệu của dòng đã chọn vào textbox
- Áp dụng cho: `txtXB`, `txtTenXB`, `txtDiaChi`

## 🔧 KIẾN TRÚC KỸ THUẬT

### DataAdapter + DataSet + CommandBuilder Pattern

**Cách hoạt động:**

1. **MySqlDataAdapter**: Cầu nối giữa DataSet và MySQL database
   - `Fill()`: Đọc dữ liệu từ DB vào DataSet (disconnected mode)
   - `Update()`: Ghi thay đổi từ DataSet về DB (Insert/Update/Delete)

2. **DataSet**: Container in-memory chứa bảng dữ liệu
   - Hoạt động offline, không cần kết nối liên tục
   - Có thể thêm/sửa/xóa rows trong memory
   - Mỗi row có trạng thái: `Unchanged`, `Added`, `Modified`, `Deleted`

3. **MySqlCommandBuilder**: Tự động tạo các lệnh SQL
   - Phân tích SELECT query để hiểu cấu trúc bảng
   - Tự sinh `InsertCommand`, `UpdateCommand`, `DeleteCommand`
   - Khi gọi `adapter.Update()`, các lệnh này được thực thi

**Quy trình CRUD:**

```
Load:
  SELECT → DataAdapter.Fill() → DataSet → DataGridView

Add:
  DataTable.NewRow() → Set values → Rows.Add() → DataAdapter.Update()

Update:
  Row.BeginEdit() → Set values → Row.EndEdit() → DataAdapter.Update()

Delete:
  Row.Delete() → DataAdapter.Update()
```

## ✅ CHECKLIST KIỂM TRA

### Trước khi chạy:

- [ ] Đã cài đặt MySQL Server và database `QuanLyBanSach` đã được tạo
- [ ] Bảng `NhaXuatBan` đã được tạo với cấu trúc đúng (XB, TenXB, DiaChi)
- [ ] Connection string trong `Config/AppConfig.cs` đã được cấu hình đúng
- [ ] MySqlConnector NuGet package đã được restore thành công

### Kiểm tra chức năng:

- [ ] **Load**: Build và chạy ứng dụng → Click "Load" → Hiển thị dữ liệu trong DataGridView
- [ ] **Add**: 
  - Nhập TenXB mới (ví dụ: "NXB Test") → Click "Thêm"
  - Hiển thị message "Thêm thành công!"
  - Click "Load" lại → Dòng mới xuất hiện
- [ ] **CellClick**: 
  - Click vào một dòng trong DataGridView
  - Textbox tự động đổ dữ liệu từ dòng đã chọn
- [ ] **Update**:
  - Chọn dòng → Sửa TenXB/DiaChi → Click "Sửa"
  - Hiển thị message "Cập nhật thành công!"
  - Click "Load" lại → Dữ liệu đã được cập nhật
- [ ] **Delete**:
  - Chọn dòng → Click "Xóa" → Xác nhận "Yes"
  - Hiển thị message "Xóa thành công!"
  - Click "Load" lại → Dòng đã bị xóa
- [ ] **Clear**: Click "Clear" → Tất cả textbox trống
- [ ] **Validation**:
  - Thử Add với TenXB rỗng → Hiển thị lỗi "Tên NXB không được để trống"
  - Thử Add với TenXB > 150 ký tự → Hiển thị lỗi "Tên NXB tối đa 150 ký tự"
  - Thử Add với TenXB trùng → Hiển thị lỗi "Tên NXB đã tồn tại"
- [ ] **Xử lý lỗi**:
  - Ngắt kết nối MySQL → Click "Load" → Hiển thị message lỗi rõ nghĩa

## 🐛 XỬ LÝ SỰ CỐ

### Lỗi: "Unable to connect to any of the specified MySQL hosts"

**Nguyên nhân:** Không kết nối được đến MySQL server

**Giải pháp:**
1. Kiểm tra MySQL server đã chạy chưa
2. Kiểm tra `Server` và `Port` trong connection string
3. Kiểm tra firewall không chặn port 3306

### Lỗi: "Access denied for user..."

**Nguyên nhân:** Sai username/password

**Giải pháp:**
1. Kiểm tra `User ID` và `Password` trong `Config/AppConfig.cs`
2. Thử kết nối bằng MySQL Workbench hoặc command line

### Lỗi: "Unknown database 'QuanLyBanSach'"

**Nguyên nhân:** Database chưa được tạo

**Giải pháp:**
```sql
CREATE DATABASE QuanLyBanSach;
```

### Lỗi: "Table 'NhaXuatBan' doesn't exist"

**Nguyên nhân:** Bảng chưa được tạo

**Giải pháp:**
Chạy script CREATE TABLE ở trên

### Lỗi: "Duplicate entry for key 'TenXB'"

**Nguyên nhân:** Tên NXB đã tồn tại (UNIQUE constraint)

**Giải pháp:**
- Ứng dụng đã xử lý, hiển thị message "Tên NXB đã tồn tại"
- Nhập tên khác

## 📝 GHI CHÚ

- Code sử dụng disconnected architecture (DataSet), phù hợp cho ứng dụng desktop
- MySqlConnector được ưu tiên hơn MySql.Data vì hiệu năng và async support tốt hơn
- Tất cả lỗi đều được catch và hiển thị MessageBox rõ nghĩa
- Validation được thực hiện ở client-side trước khi gửi về database

## 📞 SUPPORT

Nếu gặp vấn đề, kiểm tra:
1. Log lỗi trong Output window của Visual Studio
2. Connection string đã đúng chưa
3. MySQL server đã chạy và database/table đã tạo chưa


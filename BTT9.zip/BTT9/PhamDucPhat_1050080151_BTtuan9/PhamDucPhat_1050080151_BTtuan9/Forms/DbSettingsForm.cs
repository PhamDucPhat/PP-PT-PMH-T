using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;
using Config;
using Data;

namespace Forms
{
    public partial class DbSettingsForm : Form
    {
        public DbOptions? SavedOptions { get; private set; }

        public DbSettingsForm()
        {
            InitializeComponent();
            LoadSettings();
        }

        private void LoadSettings()
        {
            var options = DbSettingsService.Load();
            if (options != null)
            {
                txtHost.Text = options.Host;
                txtPort.Text = options.Port.ToString();
                txtDatabase.Text = options.Database;
                txtUser.Text = options.User;
                txtPassword.Text = options.Password;
                chkSavePassword.Checked = !string.IsNullOrEmpty(options.Password);
            }
        }

        private DbOptions GetOptionsFromUI()
        {
            uint port = 3306;
            uint.TryParse(txtPort.Text, out port);

            return new DbOptions
            {
                Host = txtHost.Text.Trim(),
                Port = port,
                Database = txtDatabase.Text.Trim(),
                User = txtUser.Text.Trim(),
                Password = chkSavePassword.Checked ? txtPassword.Text : ""
            };
        }

        private async void btnTestConnection_Click(object sender, EventArgs e)
        {
            btnTestConnection.Enabled = false;
            btnTestConnection.Text = "Đang kiểm tra...";
            Cursor = Cursors.WaitCursor;

            try
            {
                var options = GetOptionsFromUI();
                
                // Validate input
                if (string.IsNullOrWhiteSpace(options.Host))
                {
                    MessageBox.Show("Vui lòng nhập Host.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (string.IsNullOrWhiteSpace(options.Database))
                {
                    MessageBox.Show("Vui lòng nhập Database.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (string.IsNullOrWhiteSpace(options.User))
                {
                    MessageBox.Show("Vui lòng nhập User.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using var conn = MySqlDb.Get(options);
                await conn.OpenAsync();

                MessageBox.Show(
                    "✅ Kết nối thành công!\n\n" +
                    $"Host: {options.Host}:{options.Port}\n" +
                    $"Database: {options.Database}\n" +
                    $"User: {options.User}",
                    "Thành công",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (MySqlException ex) when (ex.Number == 1045)
            {
                var options = GetOptionsFromUI();
                string suggestion = "";
                if (options.Host == "localhost" || options.Host == "::1")
                {
                    suggestion += "\n• Thử đổi Host từ 'localhost' sang '127.0.0.1'\n";
                }
                if (string.IsNullOrEmpty(options.Password))
                {
                    suggestion += "\n• Đảm bảo đã nhập đúng mật khẩu\n";
                    suggestion += "• Nếu user không có password, thử để trống và bỏ tick 'Save password'\n";
                }
                else
                {
                    suggestion += "\n• Kiểm tra lại mật khẩu đã đúng chưa\n";
                    suggestion += "• Nếu quên mật khẩu, có thể reset user trong MySQL\n";
                }

                suggestion += "\n• Tạo user mới với script SQL:\n" +
                              "  CREATE USER 'app_user'@'localhost' IDENTIFIED BY 'password';\n" +
                              "  GRANT ALL ON QuanLyBanSach.* TO 'app_user'@'localhost';\n" +
                              "  FLUSH PRIVILEGES;\n";

                suggestion += "\n• Nếu dùng root, đảm bảo root có password và cho phép kết nối từ localhost\n";

                MessageBox.Show(
                    "❌ Không đăng nhập được MySQL (Lỗi 1045 - Access denied)\n\n" +
                    $"Thông báo: {ex.Message}\n\n" +
                    "Các hướng xử lý:\n" + suggestion,
                    "Lỗi kết nối - Access Denied",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            catch (MySqlException ex)
            {
                string message = $"MySQL lỗi {ex.Number}: {ex.Message}\n\n";
                
                switch (ex.Number)
                {
                    case 1049:
                        message += "Database không tồn tại. Vui lòng kiểm tra tên database.";
                        break;
                    case 2003:
                        message += "Không thể kết nối đến MySQL server.\n" +
                                   "• Kiểm tra MySQL server đã chạy chưa\n" +
                                   "• Kiểm tra Host và Port\n" +
                                   "• Kiểm tra firewall";
                        break;
                    case 0:
                        if (ex.Message.Contains("timeout"))
                        {
                            message += "Timeout kết nối. Kiểm tra:\n" +
                                       "• MySQL server có đang chạy?\n" +
                                       "• Host và Port có đúng?";
                        }
                        break;
                }

                MessageBox.Show(message, $"MySQL Error {ex.Number}", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Lỗi không xác định: {ex.Message}\n\nChi tiết: {ex.GetType().Name}",
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            finally
            {
                btnTestConnection.Enabled = true;
                btnTestConnection.Text = "Test Connection";
                Cursor = Cursors.Default;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                var options = GetOptionsFromUI();

                // Validate
                if (string.IsNullOrWhiteSpace(options.Host))
                {
                    MessageBox.Show("Vui lòng nhập Host.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtHost.Focus();
                    return;
                }
                if (string.IsNullOrWhiteSpace(options.Database))
                {
                    MessageBox.Show("Vui lòng nhập Database.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtDatabase.Focus();
                    return;
                }
                if (string.IsNullOrWhiteSpace(options.User))
                {
                    MessageBox.Show("Vui lòng nhập User.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtUser.Focus();
                    return;
                }

                // Nếu không check Save Password, không lưu password
                if (!chkSavePassword.Checked)
                {
                    options.Password = "";
                }

                DbSettingsService.Save(options);
                SavedOptions = options;

                MessageBox.Show(
                    "Đã lưu cấu hình kết nối database.\n\n" +
                    $"Host: {options.Host}:{options.Port}\n" +
                    $"Database: {options.Database}\n" +
                    $"User: {options.User}\n" +
                    $"Password: {(chkSavePassword.Checked ? "***" : "(không lưu)")}",
                    "Thành công",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Không thể lưu cấu hình: {ex.Message}",
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}


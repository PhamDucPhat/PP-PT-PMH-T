/*
 * PublisherForm - Form quản lý Nhà Xuất Bản (NhaXuatBan)
 * 
 * CÁCH HOẠT ĐỘNG CỦA DataAdapter + DataSet + CommandBuilder:
 * 
 * 1. DataAdapter: Cầu nối giữa DataSet và MySQL database
 *    - Fill(): Đọc dữ liệu từ DB vào DataSet
 *    - Update(): Ghi thay đổi từ DataSet về DB (Insert/Update/Delete)
 * 
 * 2. DataSet: Container in-memory chứa bảng dữ liệu dạng disconnected
 *    - Hoạt động offline, không cần kết nối liên tục
 *    - Có thể thêm/sửa/xóa rows trong memory
 * 
 * 3. CommandBuilder: Tự động tạo các lệnh SQL (INSERT/UPDATE/DELETE)
 *    - Phân tích SELECT query để hiểu cấu trúc bảng
 *    - Tự sinh InsertCommand, UpdateCommand, DeleteCommand
 *    - Khi gọi adapter.Update(), các lệnh này được thực thi
 * 
 * QUY TRÌNH:
 * - Load: adapter.Fill(dataset, "TableName") → đổ dữ liệu vào DataSet
 * - Add/Update/Delete: Thao tác trên DataSet.Tables["TableName"].Rows
 * - Lưu: adapter.Update(dataset, "TableName") → đồng bộ thay đổi về DB
 */

using System;
using System.Data;
using System.Windows.Forms;
using MySqlConnector;
using Config;
using Data;

namespace Forms
{
    public partial class PublisherForm : Form
    {
        private MySqlDataAdapter? _adapter;
        private DataSet? _ds;
        private DbOptions? _dbOptions;
        private const string TableName = "NhaXuatBan";

        public PublisherForm()
        {
            InitializeComponent();
            InitGrid();
            CheckDatabaseSettings();
        }

        private void CheckDatabaseSettings()
        {
            _dbOptions = DbSettingsService.Load();
            if (_dbOptions == null)
            {
                MessageBox.Show(
                    "Chưa có cấu hình database. Vui lòng cấu hình kết nối MySQL.",
                    "Cấu hình Database",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                OpenDbSettings();
            }
        }

        private DbOptions? GetDbOptions()
        {
            if (_dbOptions == null)
            {
                _dbOptions = DbSettingsService.Load();
            }
            return _dbOptions;
        }

        private MySqlConnection? CreateConnection()
        {
            var options = GetDbOptions();
            if (options == null)
            {
                MessageBox.Show(
                    "Không có cấu hình database. Vui lòng vào Menu → Hệ thống → Cấu hình Database để thiết lập.",
                    "Lỗi cấu hình",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return null;
            }
            return MySqlDb.Get(options);
        }

        private void InitGrid()
        {
            dgvNXB.AllowUserToAddRows = false;
            dgvNXB.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvNXB.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvNXB.MultiSelect = false;
            txtXB.ReadOnly = true;
            
            // Giao diện
            dgvNXB.Font = new System.Drawing.Font("Segoe UI", 10F);
            txtXB.Font = new System.Drawing.Font("Segoe UI", 10F);
            txtTenXB.Font = new System.Drawing.Font("Segoe UI", 10F);
            txtDiaChi.Font = new System.Drawing.Font("Segoe UI", 10F);
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            MySqlConnection? conn = null;
            try
            {
                conn = CreateConnection();
                if (conn == null) return;

                conn.Open();
                string sql = "SELECT XB, TenXB, DiaChi FROM NhaXuatBan ORDER BY XB;";
                _adapter = new MySqlDataAdapter(sql, conn);
                var cb = new MySqlCommandBuilder(_adapter); // Tự sinh Insert/Update/Delete

                _ds = new DataSet();
                _adapter.Fill(_ds, TableName);
                dgvNXB.DataSource = _ds.Tables[TableName];
                
                // Header đậm
                if (dgvNXB.Columns.Count > 0)
                {
                    dgvNXB.Columns[0].HeaderText = "Mã XB";
                    if (dgvNXB.Columns.Count > 1) dgvNXB.Columns[1].HeaderText = "Tên NXB";
                    if (dgvNXB.Columns.Count > 2) dgvNXB.Columns[2].HeaderText = "Địa chỉ";
                }
            }
            catch (MySqlException ex) when (ex.Number == 1045)
            {
                MessageBox.Show(
                    "❌ Không đăng nhập được MySQL (Lỗi 1045 - Access denied)\n\n" +
                    $"Thông báo: {ex.Message}\n\n" +
                    "Vui lòng kiểm tra:\n" +
                    "• Host, Port, User, Password có đúng không?\n" +
                    "• User có quyền truy cập database?\n" +
                    "• Thử đổi Host từ 'localhost' sang '127.0.0.1'\n\n" +
                    "Vào Menu → Hệ thống → Cấu hình Database để kiểm tra lại.",
                    "Lỗi kết nối - Access Denied",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(
                    $"MySQL lỗi {ex.Number}: {ex.Message}\n\n" +
                    "Vui lòng kiểm tra cấu hình database:\n" +
                    "• MySQL server có đang chạy?\n" +
                    "• Database và bảng đã được tạo chưa?\n\n" +
                    "Vào Menu → Hệ thống → Cấu hình Database để kiểm tra.",
                    $"MySQL Error {ex.Number}",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Lỗi tải dữ liệu: " + ex.Message + "\n\n" +
                    "Vui lòng kiểm tra cấu hình database:\n" +
                    "Vào Menu → Hệ thống → Cấu hình Database để kiểm tra (host/port/user/password).",
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            finally
            {
                if (conn != null && conn.State == ConnectionState.Open)
                {
                    conn.Close();
                    conn.Dispose();
                }
            }
        }

        private void dgvNXB_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || _ds == null || _ds.Tables[TableName] == null) return;
            if (e.RowIndex >= _ds.Tables[TableName].Rows.Count) return;
            
            var row = _ds.Tables[TableName].Rows[e.RowIndex];
            txtXB.Text = row["XB"]?.ToString() ?? "";
            txtTenXB.Text = row["TenXB"]?.ToString() ?? "";
            txtDiaChi.Text = row["DiaChi"]?.ToString() ?? "";
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtTenXB.Text))
            {
                MessageBox.Show("Tên NXB không được để trống.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (txtTenXB.Text.Length > 150)
            {
                MessageBox.Show("Tên NXB tối đa 150 ký tự.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (txtDiaChi.Text.Length > 255)
            {
                MessageBox.Show("Địa chỉ tối đa 255 ký tự.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;
            
            if (_ds == null || _ds.Tables[TableName] == null)
            {
                MessageBox.Show("Vui lòng Load dữ liệu trước.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            
            MySqlConnection? conn = null;
            try
            {
                var table = _ds.Tables[TableName];
                var newRow = table.NewRow();
                newRow["TenXB"] = txtTenXB.Text.Trim();
                newRow["DiaChi"] = string.IsNullOrWhiteSpace(txtDiaChi.Text) ? DBNull.Value : txtDiaChi.Text.Trim();
                table.Rows.Add(newRow);

                conn = CreateConnection();
                if (conn == null) return;

                conn.Open();
                if (_adapter != null)
                {
                    _adapter.SelectCommand.Connection = conn;
                }
                int eff = _adapter?.Update(_ds, TableName) ?? 0;
                MessageBox.Show(eff > 0 ? "Thêm thành công!" : "Không có thay đổi.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnLoad.PerformClick(); // reload
                btnClear.PerformClick();
            }
            catch (MySqlException mex) when (mex.Number == 1062) // duplicate
            {
                MessageBox.Show("Tên NXB đã tồn tại, vui lòng nhập tên khác.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (conn != null && conn.State == ConnectionState.Open)
                {
                    conn.Close();
                    conn.Dispose();
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;
            
            if (_ds == null || _ds.Tables[TableName] == null || string.IsNullOrWhiteSpace(txtXB.Text))
            {
                MessageBox.Show("Vui lòng chọn một dòng để cập nhật.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            
            MySqlConnection? conn = null;
            try
            {
                var gridIndex = dgvNXB.CurrentCell?.RowIndex ?? -1;
                if (gridIndex < 0 || gridIndex >= _ds.Tables[TableName].Rows.Count)
                {
                    MessageBox.Show("Hãy chọn một dòng.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var row = _ds.Tables[TableName].Rows[gridIndex];
                row.BeginEdit();
                row["TenXB"] = txtTenXB.Text.Trim();
                row["DiaChi"] = string.IsNullOrWhiteSpace(txtDiaChi.Text) ? DBNull.Value : txtDiaChi.Text.Trim();
                row.EndEdit();

                conn = CreateConnection();
                if (conn == null) return;

                conn.Open();
                if (_adapter != null)
                {
                    _adapter.SelectCommand.Connection = conn;
                }
                int eff = _adapter?.Update(_ds, TableName) ?? 0;
                MessageBox.Show(eff > 0 ? "Cập nhật thành công!" : "Không có thay đổi.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnLoad.PerformClick();
                btnClear.PerformClick();
            }
            catch (MySqlException mex) when (mex.Number == 1062)
            {
                MessageBox.Show("Tên NXB đã tồn tại, vui lòng nhập tên khác.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi cập nhật: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (conn != null && conn.State == ConnectionState.Open)
                {
                    conn.Close();
                    conn.Dispose();
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (_ds == null || _ds.Tables[TableName] == null || string.IsNullOrWhiteSpace(txtXB.Text))
            {
                MessageBox.Show("Vui lòng chọn một dòng để xóa.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            
            var confirm = MessageBox.Show("Bạn có chắc chắn muốn xóa NXB đã chọn?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm != DialogResult.Yes) return;

            MySqlConnection? conn = null;
            try
            {
                var gridIndex = dgvNXB.CurrentCell?.RowIndex ?? -1;
                if (gridIndex < 0 || gridIndex >= _ds.Tables[TableName].Rows.Count)
                {
                    MessageBox.Show("Hãy chọn một dòng.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var row = _ds.Tables[TableName].Rows[gridIndex];
                row.Delete();

                conn = CreateConnection();
                if (conn == null) return;

                conn.Open();
                if (_adapter != null)
                {
                    _adapter.SelectCommand.Connection = conn;
                }
                int eff = _adapter?.Update(_ds, TableName) ?? 0;
                MessageBox.Show(eff > 0 ? "Xóa thành công!" : "Không có thay đổi.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnLoad.PerformClick();
                btnClear.PerformClick();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi xóa: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (conn != null && conn.State == ConnectionState.Open)
                {
                    conn.Close();
                    conn.Dispose();
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtXB.Text = "";
            txtTenXB.Text = "";
            txtDiaChi.Text = "";
            txtTenXB.Focus();
        }

        private void OpenDbSettings()
        {
            using var settingsForm = new DbSettingsForm();
            if (settingsForm.ShowDialog() == DialogResult.OK)
            {
                _dbOptions = settingsForm.SavedOptions;
                if (_dbOptions != null)
                {
                    DbSettingsService.Save(_dbOptions);
                    MessageBox.Show("Đã cập nhật cấu hình database.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void menuDbSettings_Click(object sender, EventArgs e)
        {
            OpenDbSettings();
        }
    }
}


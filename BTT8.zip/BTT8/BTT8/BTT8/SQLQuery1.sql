﻿-- Bảng NXB
IF OBJECT_ID('dbo.NhaXuatBan','U') IS NULL
CREATE TABLE dbo.NhaXuatBan(
    NXB     CHAR(10)    NOT NULL PRIMARY KEY,
    TenNXB  NVARCHAR(100),
    DiaChi  NVARCHAR(500)
);
GO

-- Bảng Sách
IF OBJECT_ID('dbo.Sach','U') IS NULL
CREATE TABLE dbo.Sach(
    MaSach   CHAR(10)      NOT NULL PRIMARY KEY,
    TenSach  NVARCHAR(300),
    NXB      CHAR(10)      NOT NULL,
    TenTG    NVARCHAR(100),
    NamXB    DATETIME,
    GhiChu   NVARCHAR(500),
    CONSTRAINT FK_Sach_NXB FOREIGN KEY (NXB) REFERENCES dbo.NhaXuatBan(NXB)
);
GO
-- Bảng NXB
INSERT INTO dbo.NhaXuatBan(NXB, TenNXB, DiaChi) VALUES
('001', N'NXB X-Men',           N'Quang Trung, Hà Nội'),
('002', N'Khoa học xã hội',     N'Trần Phú, Hà Nội'),
('003', N'Văn hóa thể thao',    N'Hai Bà Trưng, Hà Nội');

-- Bảng Sách
INSERT INTO dbo.Sach(MaSach, TenSach, NXB, TenTG, NamXB, GhiChu) VALUES
('1', N'Lập trình C#',            '001', N'Nguyễn Lưu',  CONVERT(datetime,'2022-01-01'), N'Không'),
('2', N'ASP.NET Core',            '002', N'Trọng Khải',  CONVERT(datetime,'2019-01-01'), N'Không'),
('3', N'Lập trình Scratch',       '002', N'Bá Trọng',    CONVERT(datetime,'2021-01-01'), N'Không');
